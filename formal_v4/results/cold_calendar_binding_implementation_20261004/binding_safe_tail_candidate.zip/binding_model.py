"""Public-only boundary proposals and a terminal monotonicity certificate.

The certificate makes no weather, pointing, or factor inference.  A public
six-decimal score gives factor >= (score - 0.5e-6)/(weight*max_multiplier).
It is sufficient, deliberately incomplete, and recomputes after public resync.
"""
from datetime import timedelta
import math
import time

import numpy as np
from research.geometry import parse_utc, format_utc, altaz_to_radec, radec_to_altaz, local_sidereal_deg
from research.spatial_candidates import PROGRAMS, DEG, _shift_altaz
from research.feedback_model import seasonal_quality


class PublicScoreLedger:
    def __init__(self, initial):
        self.targets = {str(row[0]): dict(zip(initial['targets']['columns'], row))
                        for row in initial['targets']['rows']}
        program = initial['scoring']['program']
        self.maximum_multiplier = max(float(x) for x in [program['mismatch_multiplier'], *program['multipliers'].values()])
        self.threshold = float(initial['scoring']['uniformity']['observed_factor_threshold'])
        self.best = {}
        self.seen = set()
        self.resyncs = 0

    def ingest(self, snapshot):
        result = snapshot.get('last_result') or {}
        rank = result.get('observe_index')
        if result.get('action') == 'observe' and rank not in self.seen:
            self.seen.add(rank)
            for hit in result.get('hits', []):
                target = str(hit['target_id'])
                self.best[target] = max(self.best.get(target, 0.), float(hit['score']))
        # The runner publishes resync after last_result; canonical scores win.
        for message in snapshot.get('new_messages', []):
            if message.get('record_type') == 'state_resync':
                self.resyncs += 1
                self.best = {str(row['target_id']): float(row['best_score'])
                             for row in message.get('best_scores', [])}

    def factor_lower(self, target):
        weight = float(self.targets[target]['science_weight'])
        if weight <= 0:
            return 0.
        # The extra ulp prevents a binary boundary being promoted to proof.
        score_lower = max(0., self.best.get(target, 0.) - .500001e-6)
        return min(1., score_lower / (weight * self.maximum_multiplier))

    def completed(self):
        return {target for target in self.targets if self.factor_lower(target) >= self.threshold}


def terminal_certificate(initial, snapshot, original_action, candidate, ledger):
    now = parse_utc(snapshot['now_utc'])
    end = parse_utc(snapshot['survey_end_utc'])
    remaining = (end - now).total_seconds()
    if original_action.get('action') != 'wait':
        return {'adopt': False, 'reason': 'original_action_is_not_wait'}
    if 'until_utc' in original_action:
        original_end = min(end, parse_utc(original_action['until_utc']))
    else:
        original_end = min(end, now + timedelta(seconds=int(original_action['duration_seconds'])))
    if original_end != end:
        return {'adopt': False, 'reason': 'original_wait_is_not_terminal'}
    exposure = initial['instrument']['exposure']
    if not 0 < remaining < int(exposure['min_duration_seconds']):
        return {'adopt': False, 'reason': 'outside_short_terminal_tail'}
    nights = initial['survey']['nights']
    night = next((n for n in nights if parse_utc(n['observing_start_utc']) <= now < parse_utc(n['observing_end_utc'])), None)
    if night is None or parse_utc(night['observing_end_utc']) != end:
        return {'adopt': False, 'reason': 'night_end_is_not_survey_end'}
    if candidate is None or not candidate.get('assignments'):
        return {'adopt': False, 'reason': 'no_positive_certified_candidate'}
    if candidate.get('action') != 'observe' or not int(exposure['min_duration_seconds']) <= candidate['duration_seconds'] <= int(exposure['max_duration_seconds']):
        return {'adopt': False, 'reason': 'invalid_declared_duration'}
    assigned = set(candidate['assignments'].values())
    if not assigned <= ledger.completed():
        return {'adopt': False, 'reason': 'jain_completion_change_not_excluded'}
    return {'adopt': True, 'reason': 'terminal_completed_targets_monotone',
            'actual_duration_seconds': int(remaining), 'assigned_count': len(assigned),
            'factor_lower': {target: ledger.factor_lower(target) for target in sorted(assigned)},
            'science_delta_lower': 0., 'required_delta_lower': 0., 'jain_delta': 0.,
            'request_delta_lower': 0., 'loss_rank_future_effect': False}


def prenight_certificate(snapshot, proposal, replaces_first_observe=False):
    # No policy can certify its future strong first action before unseen night
    # bulletins/requests arrive. Equal observe counts alone is insufficient.
    return {'adopt': False, 'reason': 'unseen_night_start_information_and_counterfactual_action',
            'future_truth_used': False, 'rank_change': 0 if replaces_first_observe else 1,
            'pending_loss_rank_risk': not replaces_first_observe,
            'same_end_does_not_certify_same_strong_action': True}


class BoundarySearch:
    """A bounded deterministic search that does not call/mutate strong choose."""
    def __init__(self, owner, ledger, anchors=24):
        self.owner, self.p, self.ledger, self.anchors = owner, owner.planner, ledger, anchors

    def _quality(self, night_start, seconds, indices):
        p = self.p
        cursor, end = night_start, night_start + timedelta(seconds=seconds)
        total = np.zeros(len(indices))
        night = next(a for a, b in p.nights if a <= night_start < b)
        while cursor < end:
            slot_end = night + timedelta(seconds=(int((cursor-night).total_seconds())//self.owner.slot_seconds+1)*self.owner.slot_seconds)
            piece_end = min(end, slot_end, cursor+timedelta(seconds=120))
            total += (piece_end-cursor).total_seconds()*p._subset_public_quality(cursor+(piece_end-cursor)/2, indices)
            cursor = piece_end
        return total

    def search(self, snapshot, terminal=True, lead=0, effective_seconds=None):
        begin = time.perf_counter(); p = self.p
        now = parse_utc(snapshot['now_utc'])
        if terminal:
            night = next((j for j,(a,b) in enumerate(p.nights) if a <= now < b), None)
            if night is None: return {'chosen': None, 'seconds': time.perf_counter()-begin}
            effective = (p.nights[night][1]-now).total_seconds()
            start, night_start, full = now, now, int(effective)
            allowed = self.ledger.completed()
        else:
            night = next((j for j,(a,b) in enumerate(p.nights) if a > now), None)
            if night is None: return {'chosen': None, 'seconds': time.perf_counter()-begin}
            night_start = p.nights[night][0]; start = night_start-timedelta(seconds=lead)
            effective = min(effective_seconds or 900, (p.nights[night][1]-night_start).total_seconds())
            full = int(lead+effective); allowed = set(p.ids)
            if start < now or full > p.tmax: return {'chosen': None, 'seconds': time.perf_counter()-begin}
        indices = np.asarray([i for i,t in enumerate(p.ids) if t in allowed], dtype=int)
        if not len(indices): return {'chosen': None, 'seconds': time.perf_counter()-begin, 'eligible_count': 0}
        alt, az, up, vectors = p._geometry(start)
        indices = indices[(alt[indices] >= p.min_alt+.04) & (up[indices] >= full+1)]
        if not len(indices): return {'chosen': None, 'seconds': time.perf_counter()-begin, 'eligible_count': 0}
        C,E = self.owner.belief_clock.prior(self.owner.C,self.owner.E,night_start,seasonal_quality(night_start.timetuple().tm_yday,p.q0)[0])
        h = self._quality(night_start,int(effective),indices)
        factors = np.minimum(1.,p.flux[indices]*h*C*E*p.q0/p.f0t0)
        band_quality = h*C*p.q0/max(1,full)
        bands = np.where(band_quality>=p.dark_threshold,0,np.where(band_quality>=p.bright_threshold,1,2))
        mult = np.where(bands[None,:]==np.arange(3)[:,None],p.multipliers[:,None],p.mismatch)
        scores = np.asarray([self.ledger.best.get(p.ids[i],0.) for i in indices])
        values = np.maximum(0.,p.weight[indices][None,:]*factors[None,:]*mult-scores[None,:])
        merit = values.max(axis=0)
        order = np.argsort(-merit,kind='stable')
        anchors=[]
        for j in order:
            i=int(indices[j])
            if merit[j] <= 1e-12: break
            if all(p.eq_vectors[i]@p.eq_vectors[k]<math.cos(.35*p.fov*DEG) for k in anchors): anchors.append(i)
            if len(anchors) >= self.anchors: break
        off=self.owner.calibrator.estimate[:2] if self.owner.calibrator else (0.,0.)
        best=None; centers_checked=0
        for anchor in anchors:
            for fiber in range(p.nfib):
                row,col=divmod(fiber,p.side)
                center=_shift_altaz(float(alt[anchor]),float(az[anchor]),-(row-(p.side-1)/2)*p.pitch,-(col-(p.side-1)/2)*p.pitch)
                if not 0 <= center[0]-off[0] <= 90: continue
                fibers,valid,_=p._classify(vectors[indices],*center); centers_checked+=1
                for program in range(3):
                    chosen=[]
                    for fiber_id in range(p.nfib):
                        choices=np.flatnonzero(valid & (fibers==fiber_id))
                        if len(choices):
                            j=int(choices[np.argmax(values[program,choices])])
                            if values[program,j]>1e-12: chosen.append(j)
                    gain=float(values[program,chosen].sum())
                    if chosen and (best is None or gain>best['predicted_science_gain']):
                        assignment={str(int(fibers[j])):p.ids[int(indices[j])] for j in chosen}
                        action={'action':'observe','pointing':{'alt_deg':round(float(center[0]-off[0]),7),'az_deg':round(float((center[1]-off[1])%360),7)},
                                'assignments':assignment,'duration_seconds':p.tmin if terminal else full,'program':PROGRAMS[program]}
                        best={'action':action,'start_utc':format_utc(start),'lead_seconds':lead,'effective_seconds':int(effective),
                              'predicted_science_gain':gain,'C':C,'E':E,'predicted_factors':{p.ids[int(indices[j])]:float(factors[j]) for j in chosen},
                              'future_truth_used':False}
        return {'chosen':best,'seconds':time.perf_counter()-begin,'eligible_count':len(indices),'centers_checked':centers_checked,
                'belief_forecast_only':True,'exact_counterfactual_score':False}


def proposal_prediction(owner,row):
    p=owner.planner;start=parse_utc(row['start_utc']);alt,az,_,_=p._geometry(start)
    return {target:{'index':int(p.index[target]),'fiber_id':int(fiber),'factor':row['predicted_factors'][target],
            'public_quality':1.,'quality':row['predicted_factors'][target]*p.f0t0/(max(1e-12,p.flux[p.index[target]])*row['action']['duration_seconds']),
            'directional_scale':1.,'predicted_band':row['action']['program'],
            'alt_deg':float(alt[p.index[target]]),'az_deg':float(az[p.index[target]])}
            for fiber,target in row['action']['assignments'].items()}
