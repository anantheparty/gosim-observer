"""The original 29-file strong policy plus a certified terminal tail only."""
import os
from pathlib import Path
import sys
import json
import time
os.environ.setdefault('OPENBLAS_NUM_THREADS','1')
os.environ.setdefault('OMP_NUM_THREADS','1')
sys.dont_write_bytecode=True
sys.path.insert(0,str(Path(__file__).resolve().parent/'base'))
from research import agent_request_exact_cache as frozen
import agent
from binding_model import PublicScoreLedger,BoundarySearch,terminal_certificate
from research.geometry import parse_utc


class BoundaryPolicy(frozen.ExactCachedRequestPolicy):
    def __init__(self,initial):
        super().__init__(initial)
        envelope=json.loads((Path(__file__).resolve().parent/'public_weather_envelope.json').read_text())
        self.boundary_ledger=PublicScoreLedger(initial,family_weather_ratio=float(envelope['maximum_weather_component_ratio']))
        self.boundary_search=BoundarySearch(self,self.boundary_ledger)
        self.boundary_stats={'searches':0,'adopted':0,'seconds':0.,'certificate':None}

    def decide(self,snapshot):
        started=time.perf_counter()
        self.boundary_ledger.ingest(snapshot)
        original=super().decide(snapshot)
        now=parse_utc(snapshot['now_utc']); end=parse_utc(snapshot['survey_end_utc'])
        if original.get('action')!='wait' or not 0<(end-now).total_seconds()<self.planner.tmin:
            return original
        remaining=float((snapshot.get('wallclock') or {}).get('remaining_seconds',900))
        if remaining<10.:
            return original
        result=self.boundary_search.search(snapshot,terminal=True)
        self.boundary_stats['searches']+=1; self.boundary_stats['seconds']+=result['seconds']
        row=result['chosen']; action=row['action'] if row else None
        certificate=terminal_certificate(self.initial,snapshot,original,action,self.boundary_ledger)
        self.boundary_stats['certificate']=certificate
        if remaining-(time.perf_counter()-started)<2.:
            return original
        if not certificate['adopt']: return original
        self.boundary_stats['adopted']+=1
        # This action reaches E; no feedback, planner update, or actor roundtrip follows.
        self.pending=None
        return action

    def summary(self):
        return {**super().summary(),'calendar_boundary':self.boundary_stats}


def make_boundary_policy(base):
    """Compose above an existing RequestCache-derived public controller.

    Keep a terminal report guard outside this class so it freezes the final
    certified observe, reports, and releases that same action as before.
    """
    if not issubclass(base,frozen.ExactCachedRequestPolicy):
        raise TypeError('boundary composition requires the original strong RequestCache ancestry')
    if base is frozen.ExactCachedRequestPolicy:return BoundaryPolicy
    return type('CertifiedBoundaryPolicy',(BoundaryPolicy,base),{})


agent.Policy=BoundaryPolicy
if __name__=='__main__': agent.main()
