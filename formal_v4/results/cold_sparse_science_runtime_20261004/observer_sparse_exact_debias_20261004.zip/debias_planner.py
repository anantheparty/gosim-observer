"""Public science seed debias; inherited rate and physical evaluation preserved."""
from __future__ import annotations
import math
import time
import numpy as np
from research.spatial_candidates import (SpatialPlanner, DEG, PROGRAMS, parse_utc, local_sidereal, SIDEREAL_SPEED, DIRECTION_AZ, _wrap180, _shift_altaz)

class DebiasedSpatialPlanner(SpatialPlanner):
    def _evaluate(self, center, pool, *frame):
        self.decision_frame=frame
        return super()._evaluate(center,pool,*frame)

    def choose(self, snapshot, best_scores, best_factors, env_estimate=None, active_requests=None):
        started = time.perf_counter()
        env = env_estimate or {}
        budget = max(.01, float(env.get("planning_budget_seconds", .095)))
        now = parse_utc(snapshot["now_utc"])
        current_night = next((k for k, (start, end) in enumerate(self.nights) if start <= now < end), None)
        if current_night is None:
            return None
        seconds_left = min(self.tmax, int((self.nights[current_night][1] - now).total_seconds()))
        if seconds_left < self.tmin:
            return None
        scores, factors = self._array(best_scores), self._array(best_factors)
        lst = local_sidereal(now, self.lon)
        alt, az, hour, vectors = self._altaz(lst)
        up = np.where(self.hmax >= 180, 1e9, (self.hmax - hour) / SIDEREAL_SPEED)
        up = np.maximum(0, up - 1)
        visible = (alt >= self.min_alt + .04) & (up >= self.tmin)
        public_quality = self._public_quality(now, lst, alt)
        quality_scale = max(.005, float(env.get("quality_scale", .55)))
        band_scale = max(.005, float(env.get("program_band_quality_scale", quality_scale / .95)))
        scale = np.full(self.n, quality_scale)
        directional_scale = np.ones(self.n)
        notices = (snapshot.get("latest_bulletin") or {}).get("notices", [])
        for message in snapshot.get("new_messages", []):
            if message.get("record_type") == "bulletin" and message.get("initial"):
                self.terrain_directions.update(n.get("direction") for n in message.get("notices", []) if n.get("event_kind") == "terrain_obstruction")
        if (snapshot.get("latest_bulletin") or {}).get("initial"):
            self.terrain_directions.update(n.get("direction") for n in notices if n.get("event_kind") == "terrain_obstruction")
        if env.get("use_bulletin_directional_prior", True):
            directional_notices = list(notices) + [{"event_kind": "terrain_obstruction", "direction": d} for d in self.terrain_directions]
            for notice in directional_notices:
                direction = notice.get("direction")
                if direction not in DIRECTION_AZ:
                    continue
                kind = notice.get("event_kind")
                near = np.abs(_wrap180(az - DIRECTION_AZ[direction])) <= 55.0
                limit, prior = (47.0, .25) if kind == "terrain_obstruction" else ((62.0, .35) if kind == "rocket_launch" else (73.0, .7))
                directional_scale[near & (alt < limit)] = np.minimum(directional_scale[near & (alt < limit)], prior)
        for direction, prior in env.get("directional_quality_scales", {}).items():
            if direction in DIRECTION_AZ:
                near = np.abs(_wrap180(az - DIRECTION_AZ[direction])) <= 60.0
                directional_scale[near & (alt < 75.0)] *= float(prior)
        scale *= directional_scale
        if env.get("target_quality_scale") is not None:
            scale *= np.asarray(env["target_quality_scale"], dtype=float)
        safety = max(1.0, float(env.get("duration_safety", 1.06)))
        quality = public_quality * scale
        k = self.flux * quality / max(1e-9, self.f0t0)
        actual_bands = np.where(public_quality * band_scale >= self.dark_threshold, 0,
                               np.where(public_quality * band_scale >= self.bright_threshold, 1, 2))
        multiplier = np.where(actual_bands[None, :] == np.arange(3)[:, None], self.multipliers[:, None], self.mismatch)
        req_missing = self.required & (factors + 1e-8 < self.req_threshold)
        req_reward, request_threshold, request_deadline, prepared_requests = self._request_terms(active_requests if active_requests is not None else snapshot.get("active_requests", []), now)
        focus_request = None
        if prepared_requests:
            req, request_idx, left, req_t, deadline = max(prepared_requests, key=lambda x: float(x[0].get("completion_reward", 0)) / x[2])
            membership = np.zeros(self.n, dtype=bool)
            membership[request_idx] = True
            focus_request = (membership, float(req.get("completion_reward", 0)), left, req_t, deadline)
        max_duration = np.minimum(up, seconds_left)
        reachable = np.minimum(1.0, k * max_duration / safety)
        science_potential = np.maximum(0, self.weight * reachable * np.max(multiplier, axis=0) - scores)
        eligible_req = req_missing & (reachable >= self.req_threshold)
        eligible_request = (req_reward > 0) & (reachable >= request_threshold)
        nights_left = np.maximum(1, self.future_nights[current_night])
        urgency = 1 + .8 / nights_left + .3 * np.maximum(hour, 0) / np.maximum(self.hmax, 1)
        priority = science_potential.copy()
        priority += eligible_req * self.req_penalty * np.minimum(1, k * 900 / self.req_threshold)
        priority += eligible_request * req_reward * np.minimum(1, k * 900 / np.maximum(request_threshold, .01))
        priority *= urgency * visible
        positive = np.flatnonzero(priority > 1e-10)
        if not len(positive):
            return None
        # Smooth uniformity pressure from the exact Jain-index derivative.
        completed = factors >= self.uniform_threshold
        band_completed = np.bincount(self.ra_bands, weights=completed, minlength=len(self.band_sizes))
        proportions = np.divide(band_completed, self.band_sizes, out=np.zeros_like(band_completed), where=self.band_sizes > 0)
        s, v = float(proportions.sum()), float(proportions @ proportions)
        uniform_bonus = np.zeros(self.n)
        if v > 0:
            gradient = (2 * s / (self.nonempty_bands * v) - 2 * s * s * proportions / (self.nonempty_bands * v * v))
            grad_per_target = np.divide(gradient, self.band_sizes, out=np.zeros_like(gradient), where=self.band_sizes > 0)
            progress_scale = min(1.0, float(completed.mean()) / .2)
            uniform_bonus = self.uniform_weight * progress_scale * grad_per_target[self.ra_bands]
        # Dense-bin seeds plus individual priorities avoid isolated-bright-star bias.
        bin_values = np.bincount(self.space_bins, weights=priority, minlength=self.bin_count)
        top_bins = np.argsort(bin_values)[-min(24, self.bin_count):][::-1]
        seeds = []
        for b in top_bins:
            members = np.flatnonzero((self.space_bins == b) & (priority > 0))
            if len(members):
                seeds.append(int(members[np.argmax(priority[members])]))
        seeds.extend(int(i) for i in positive[np.argsort(priority[positive])[-12:][::-1]])
        anchors = []
        cosine_separation = math.cos(max(.3, self.fov * .35) * DEG)
        for i in seeds:
            if all(float(self.eq_vectors[i] @ self.eq_vectors[j]) < cosine_separation for j in anchors):
                anchors.append(i)
            if len(anchors) >= int(env.get("anchor_count", 8)):
                break
        fiber_positions = np.arange(self.nfib)
        if self.nfib > 25:
            selected = np.unique(np.rint(np.linspace(0, self.side - 1, 5)).astype(int))
            fiber_positions = np.asarray([r * self.side + c for r in selected for c in selected])
        best = None
        evaluated = 0
        radius_cosine = math.cos((self.fov * math.sqrt(2) + .3) * DEG)
        for anchor in anchors:
            pool = np.flatnonzero(visible & (np.sum(self.eq_vectors * self.eq_vectors[anchor], axis=1) >= radius_cosine) & (priority > 0))
            for f in fiber_positions:
                if best is not None and time.perf_counter() - started > budget:
                    break
                row, col = divmod(int(f), self.side)
                dn, de = (row - (self.side - 1) / 2) * self.pitch, (col - (self.side - 1) / 2) * self.pitch
                center = _shift_altaz(float(alt[anchor]), float(az[anchor]), -dn, -de)
                if not 0.0 <= center[0] <= 90.0:
                    continue
                candidate = self._evaluate(center, pool, vectors, up, k, scores, factors, multiplier, req_missing,
                                           req_reward, request_threshold, request_deadline, uniform_bonus, urgency,
                                           seconds_left, safety, focus_request)
                evaluated += 1
                if candidate and (best is None or candidate[0] > best[0]):
                    best = candidate
            if best is not None and time.perf_counter() - started > budget:
                break
        # Refine the strongest pointing at two spatial resolutions when budget permits.
        if best is not None:
            refine_pool = np.flatnonzero(visible & (priority > 0))
            for fraction in (.22, .08):
                base = best[1]
                for dn, de in ((0, -1), (0, 1), (-1, 0), (1, 0), (-1, -1), (1, 1), (-1, 1), (1, -1)):
                    if time.perf_counter() - started > budget:
                        break
                    center = _shift_altaz(*base, dn * self.pitch * fraction, de * self.pitch * fraction)
                    a, z = center[0] * DEG, center[1] * DEG
                    cvec = np.array([math.cos(a) * math.cos(z), math.cos(a) * math.sin(z), math.sin(a)])
                    pool = refine_pool[(np.sum(vectors[refine_pool] * cvec, axis=1)) >= math.cos(self.fov * DEG)]
                    candidate = self._evaluate(center, pool, vectors, up, k, scores, factors, multiplier, req_missing,
                                               req_reward, request_threshold, request_deadline, uniform_bonus, urgency,
                                               seconds_left, safety, focus_request)
                    evaluated += 1
                    if candidate and candidate[0] > best[0]:
                        best = candidate
        self.stats = {"planning_seconds": time.perf_counter() - started, "candidates": evaluated,
                      "visible_useful": len(positive), "anchors": len(anchors)}
        if best is None:
            self.last_prediction = {}
            return None
        _, center, duration, program, chosen, fibers = best
        offset_alt = float(env.get("pointing_offset_alt_deg", 0.0))
        offset_az = float(env.get("pointing_offset_az_deg", 0.0))
        cmd_alt = center[0] - offset_alt
        if not 0 <= cmd_alt <= 90:
            return None
        self.last_prediction = {self.ids[int(i)]: {"index": int(i), "fiber_id": int(f), "factor": min(1., float(k[i] * duration)),
                                                  "public_quality": float(public_quality[i]), "quality": float(quality[i]),
                                                  "directional_scale": float(directional_scale[i]),
                                                  "predicted_band": PROGRAMS[int(actual_bands[i])],
                                                  "alt_deg": float(alt[i]), "az_deg": float(az[i])}
                                for i, f in zip(chosen, fibers)}
        return {"action": "observe", "pointing": {"alt_deg": round(cmd_alt, 7), "az_deg": round((center[1] - offset_az) % 360, 7)},
                "assignments": {str(int(f)): self.ids[int(i)] for i, f in zip(chosen, fibers)},
                "duration_seconds": int(duration), "program": PROGRAMS[int(program)]}
