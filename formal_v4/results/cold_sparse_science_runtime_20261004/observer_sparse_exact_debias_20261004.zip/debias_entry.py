"""Normal full-season RequestCache entry with science seed debias.

DEBIAS_ENABLED=0 disables the new baseline hook for exact action parity.
No prefix, cut, stop, past tape, future truth, or service price exists here.
"""
from __future__ import annotations
import os
os.environ.setdefault('OPENBLAS_NUM_THREADS','1')
os.environ.setdefault('OMP_NUM_THREADS','1')
os.environ.setdefault('MKL_NUM_THREADS','1')
import math
import numpy as np
from research import agent_request_exact_cache as entry
from research.spatial_candidates import PROGRAMS, DEG, parse_utc, local_sidereal
from debias_planner import DebiasedSpatialPlanner
import agent
import policy

ENABLED=os.environ.get('DEBIAS_ENABLED','1')!='0'

class DebiasedRequestPlanner(entry.ExactCachedRequestRemotePlanner):
    def __init__(self,initial):
        super().__init__(initial)
        self.debias_engine=DebiasedSpatialPlanner(initial)
        self.debias_counts={'calls':0,'changed':0,'enabled':ENABLED}

    def _action(self,p,candidate,env):
        _,center,duration,program,chosen,fibers=candidate
        return {'action':'observe','pointing':{'alt_deg':round(center[0]-float(env.get('pointing_offset_alt_deg',0)),7),
            'az_deg':round((center[1]-float(env.get('pointing_offset_az_deg',0)))%360,7)},
            'duration_seconds':int(duration),'program':PROGRAMS[int(program)],
            'assignments':{str(int(f)):p.ids[int(i)] for i,f in zip(chosen,fibers)}}

    def _prediction(self,p,action,snapshot,env):
        now=parse_utc(snapshot['now_utc']);lst=local_sidereal(now,p.lon)
        alt,az,_,_=p._altaz(lst);public=p._public_quality(now,lst,alt)
        scale=max(.005,float(env.get('quality_scale',.55)))
        directional=np.asarray(env.get('target_quality_scale',np.ones(p.n)))
        quality=public*scale*directional
        bs=max(.005,float(env.get('program_band_quality_scale',scale/.95)))
        band=np.where(public*bs>=p.dark_threshold,0,np.where(public*bs>=p.bright_threshold,1,2))
        return {t:{'index':p.index[t],'fiber_id':int(f),'factor':min(1.,float(p.flux[p.index[t]]*quality[p.index[t]]*action['duration_seconds']/p.f0t0)),
            'public_quality':float(public[p.index[t]]),'quality':float(quality[p.index[t]]),'directional_scale':1.,
            'predicted_band':PROGRAMS[int(band[p.index[t]])],'alt_deg':float(alt[p.index[t]]),'az_deg':float(az[p.index[t]])}
            for f,t in action['assignments'].items()}

    def _choose_baseline(self,snapshot,scores,factors,env,active_requests):
        baseline=super()._choose_baseline(snapshot,scores,factors,env,active_requests)
        if not ENABLED or baseline is None or baseline.get('action')!='observe':return baseline
        prior_prediction=dict(self.last_prediction);prior_stats=dict(self.stats)
        p=self.debias_engine;p.tmax=self.tmax;p.stats={};p.last_prediction={}
        chosen=p.choose(snapshot,scores,factors,dict(env,planning_budget_seconds=1e9,anchor_count=24),active_requests)
        frame=getattr(p,'decision_frame',None)
        if frame is None or chosen is None:
            self.last_prediction=prior_prediction;self.stats=prior_stats
            return baseline
        visible=(frame[0][:,2]>=math.sin((p.min_alt+.04)*DEG))&(frame[1]>=p.tmin)
        pool=np.flatnonzero(visible)
        def evaluate(action):
            center=(action['pointing']['alt_deg']+float(env.get('pointing_offset_alt_deg',0)),
                (action['pointing']['az_deg']+float(env.get('pointing_offset_az_deg',0)))%360)
            return p._evaluate(center,pool,*frame)
        retained=evaluate(baseline);candidate=evaluate(chosen)
        best=retained if candidate is None or retained is not None and retained[0]>=candidate[0] else candidate
        if best is None:
            self.last_prediction=prior_prediction;self.stats=prior_stats
            return baseline
        selected=self._action(p,best,env)
        self.last_prediction=self._prediction(p,selected,snapshot,env)
        self.stats={**prior_stats,'debias_enabled':True,'debias_rate':float(best[0])}
        self.debias_counts['calls']+=1
        self.debias_counts['changed']+=selected!=baseline
        return selected

class DebiasedRequestPolicy(entry.ExactCachedRequestPolicy):
    def summary(self):
        return {**super().summary(),'science_seed_debias':dict(self.planner.debias_counts)}

entry.ExactCachedRequestRemotePlanner=DebiasedRequestPlanner
policy.SpatialPlanner=DebiasedRequestPlanner
policy.Policy=DebiasedRequestPolicy
agent.Policy=DebiasedRequestPolicy

if __name__=='__main__':agent.main()
