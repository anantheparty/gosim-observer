"""Normal frozen report policy with exact arithmetic installed first."""
import os
os.environ.setdefault('OPENBLAS_NUM_THREADS','1')
os.environ.setdefault('OMP_NUM_THREADS','1')
os.environ.setdefault('MKL_NUM_THREADS','1')
from sparse_exact import install
install()
import report_entry
if __name__ == '__main__': report_entry.agent.main()
